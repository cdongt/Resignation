# -*- coding: utf-8 -*-
"""
发票识别API调用示例
使用 qwen3-vl-plus 视觉模型识别发票，然后提取JSON

流程：
1. 图片 → qwen3-vl-plus → Markdown
2. Markdown → qwen-plus/qwen-turbo → JSON
"""

import os
import base64
import json
from pathlib import Path

# 导入提示词
from invoice_recognition_prompt import get_prompt, SYSTEM_PROMPT, USER_PROMPT
from invoice_extraction_prompt import get_extraction_prompt, create_messages


# =============================================================================
# 配置
# =============================================================================
# 阿里云API配置（请替换为你的实际配置）
DASHSCOPE_API_KEY = os.getenv("DASHSCOPE_API_KEY", "your-api-key-here")
DASHSCOPE_BASE_URL = "https://dashscope.aliyuncs.com/compatible-mode/v1"

# 模型配置
VISION_MODEL = "qwen-vl-plus"  # 视觉模型，用于OCR识别
TEXT_MODEL = "qwen-plus"  # 文本模型，用于JSON提取


# =============================================================================
# 工具函数
# =============================================================================
def image_to_base64(image_path: str) -> str:
    """将图片转换为base64编码"""
    with open(image_path, "rb") as f:
        return base64.b64encode(f.read()).decode("utf-8")


def get_image_mime_type(image_path: str) -> str:
    """获取图片MIME类型"""
    suffix = Path(image_path).suffix.lower()
    mime_types = {
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".gif": "image/gif",
        ".webp": "image/webp",
    }
    return mime_types.get(suffix, "image/png")


# =============================================================================
# 方式一：使用 OpenAI SDK（推荐）
# =============================================================================
def recognize_invoice_openai(image_path: str, prompt_type: str = "standard") -> str:
    """
    使用OpenAI SDK调用qwen-vl-plus识别发票
    
    Args:
        image_path: 发票图片路径
        prompt_type: 提示词类型（standard/simple/enhanced）
    
    Returns:
        str: Markdown格式的识别结果
    """
    from openai import OpenAI
    
    client = OpenAI(
        api_key=DASHSCOPE_API_KEY,
        base_url=DASHSCOPE_BASE_URL,
    )
    
    # 获取提示词
    system_prompt, user_prompt = get_prompt(prompt_type)
    
    # 图片转base64
    image_base64 = image_to_base64(image_path)
    mime_type = get_image_mime_type(image_path)
    image_url = f"data:{mime_type};base64,{image_base64}"
    
    # 调用API
    response = client.chat.completions.create(
        model=VISION_MODEL,
        messages=[
            {"role": "system", "content": system_prompt},
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": user_prompt},
                    {"type": "image_url", "image_url": {"url": image_url}},
                ],
            },
        ],
        temperature=0.1,  # 低温度确保稳定输出
        max_tokens=4096,
    )
    
    return response.choices[0].message.content


def extract_json_openai(markdown_content: str, prompt_type: str = "standard") -> dict:
    """
    使用OpenAI SDK从Markdown提取JSON
    
    Args:
        markdown_content: Markdown格式的发票识别结果
        prompt_type: 提示词类型（standard/simple/business）
    
    Returns:
        dict: 提取的JSON数据
    """
    from openai import OpenAI
    
    client = OpenAI(
        api_key=DASHSCOPE_API_KEY,
        base_url=DASHSCOPE_BASE_URL,
    )
    
    # 获取提示词
    messages = create_messages(markdown_content, prompt_type)
    
    # 调用API
    response = client.chat.completions.create(
        model=TEXT_MODEL,
        messages=messages,
        temperature=0.1,
        max_tokens=4096,
    )
    
    result = response.choices[0].message.content
    
    # 清理JSON字符串（去除可能的markdown代码块标记）
    result = result.strip()
    if result.startswith("```json"):
        result = result[7:]
    if result.startswith("```"):
        result = result[3:]
    if result.endswith("```"):
        result = result[:-3]
    result = result.strip()
    
    return json.loads(result)


# =============================================================================
# 方式二：使用 requests 直接调用
# =============================================================================
def recognize_invoice_requests(image_path: str, prompt_type: str = "standard") -> str:
    """
    使用requests直接调用API识别发票
    
    Args:
        image_path: 发票图片路径
        prompt_type: 提示词类型
    
    Returns:
        str: Markdown格式的识别结果
    """
    import requests
    
    # 获取提示词
    system_prompt, user_prompt = get_prompt(prompt_type)
    
    # 图片转base64
    image_base64 = image_to_base64(image_path)
    mime_type = get_image_mime_type(image_path)
    image_url = f"data:{mime_type};base64,{image_base64}"
    
    # 构建请求
    url = f"{DASHSCOPE_BASE_URL}/chat/completions"
    headers = {
        "Authorization": f"Bearer {DASHSCOPE_API_KEY}",
        "Content-Type": "application/json",
    }
    
    payload = {
        "model": VISION_MODEL,
        "messages": [
            {"role": "system", "content": system_prompt},
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": user_prompt},
                    {"type": "image_url", "image_url": {"url": image_url}},
                ],
            },
        ],
        "temperature": 0.1,
        "max_tokens": 4096,
    }
    
    response = requests.post(url, headers=headers, json=payload)
    response.raise_for_status()
    
    return response.json()["choices"][0]["message"]["content"]


# =============================================================================
# 完整处理流程
# =============================================================================
def process_invoice(image_path: str, 
                    recognition_type: str = "enhanced",
                    extraction_type: str = "business") -> dict:
    """
    完整的发票处理流程：识别 → 提取
    
    Args:
        image_path: 发票图片路径
        recognition_type: 识别提示词类型
        extraction_type: 提取提示词类型
    
    Returns:
        dict: 包含markdown和json结果
    """
    print(f"[1/2] 正在识别发票: {image_path}")
    markdown_result = recognize_invoice_openai(image_path, recognition_type)
    
    print(f"[2/2] 正在提取JSON...")
    json_result = extract_json_openai(markdown_result, extraction_type)
    
    return {
        "image_path": image_path,
        "markdown": markdown_result,
        "json": json_result,
    }


def process_batch(image_dir: str, output_dir: str = None) -> list:
    """
    批量处理发票图片
    
    Args:
        image_dir: 图片目录
        output_dir: 输出目录（默认为image_dir/output）
    
    Returns:
        list: 处理结果列表
    """
    image_dir = Path(image_dir)
    output_dir = Path(output_dir) if output_dir else image_dir / "output"
    output_dir.mkdir(exist_ok=True)
    
    results = []
    image_files = list(image_dir.glob("*.png")) + list(image_dir.glob("*.jpg"))
    
    for i, image_path in enumerate(image_files, 1):
        print(f"\n{'='*50}")
        print(f"处理 [{i}/{len(image_files)}]: {image_path.name}")
        print('='*50)
        
        try:
            result = process_invoice(str(image_path))
            results.append(result)
            
            # 保存单个结果
            output_file = output_dir / f"{image_path.stem}.json"
            with open(output_file, "w", encoding="utf-8") as f:
                json.dump(result["json"], f, ensure_ascii=False, indent=2)
            
            print(f"✓ 已保存: {output_file}")
            
        except Exception as e:
            print(f"✗ 处理失败: {e}")
            results.append({"image_path": str(image_path), "error": str(e)})
    
    # 保存汇总结果
    summary_file = output_dir / "all_invoices.json"
    with open(summary_file, "w", encoding="utf-8") as f:
        json.dump([r.get("json", r) for r in results], f, ensure_ascii=False, indent=2)
    
    print(f"\n汇总文件已保存: {summary_file}")
    return results


# =============================================================================
# 主程序
# =============================================================================
if __name__ == "__main__":
    # 示例：处理单张发票
    # result = process_invoice("out/20251212153907472663_1.png")
    # print(json.dumps(result["json"], ensure_ascii=False, indent=2))
    
    # 示例：批量处理
    # results = process_batch("out/")
    
    print("发票识别示例程序")
    print("-" * 40)
    print("使用方法:")
    print("1. 设置环境变量 DASHSCOPE_API_KEY")
    print("2. 调用 process_invoice(image_path) 处理单张发票")
    print("3. 调用 process_batch(image_dir) 批量处理")
    print()
    print("提示词类型:")
    print("- recognition_type: standard, simple, enhanced")
    print("- extraction_type: standard, simple, business")

