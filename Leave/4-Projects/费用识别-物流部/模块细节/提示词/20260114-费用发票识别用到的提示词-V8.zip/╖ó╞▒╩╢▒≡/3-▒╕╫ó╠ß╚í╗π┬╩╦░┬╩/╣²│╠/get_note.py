import json


def get_note_from_file(file_path,output_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    note_list = []
    for item in data:
        note = item['备注']
        if note:
            note_list.append({'备注': note})
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(note_list, f, ensure_ascii=False, indent=4)

if __name__ == '__main__':
    get_note_from_file('20251224-markdown提取json.json', 'output.json')
