def read_markdown(file_path):
    """读取markdown文件并返回文本内容"""
    with open(file_path, 'r', encoding='utf-8') as f:
        return f.read()



if __name__ == "__main__":
    md2text = read_markdown("E:\gitProjects\mineru\markdown\帝威 2025.8.1-8.31费用确认.md")
    print(md2text)