import json

def get_wxht_from_json(json_path):
    with open(json_path, 'r', encoding='utf-8') as f:
        return json.load(f)

def read_json(json_path):
    with open(json_path, 'r', encoding='utf-8') as f:
        return json.load(f)

def preview_json(json_data,count):
    if isinstance(json_data,list):
        for item in json_data[:count]:
            item_list = json.loads(item['content'])
            wxht = item_list[0]['wxht']
            new_data = {'外销合同号':wxht}

def extract_wxht(json_data):
    wxht_list = []
    for item in json_data:
        item_list = json.loads(item['content'])
        wxht = item_list[0]['wxht']
        wxht_list.append(wxht)
    with open('wxht_list.txt','w',encoding='utf-8') as f:
        for wxht in wxht_list:
            f.write(wxht + '\n')


    


if __name__ == "__main__":
    json_file = "cost_ident_record.json"
    json_data = read_json(json_file)
    preview_json(json_data,10)
    extract_wxht(json_data)
    