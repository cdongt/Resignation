import os
from dashscope import Generation


def call_qwen_text_models(model_name, prompt, system_prompt=None):
    """
    调用通义千问文本模型处理文本
    
    Args:
        model_name (str): 模型名称，如 "qwen-max", "qwen-plus", "qwen-turbo"
        prompt (str): 用户输入的文本提示
        system_prompt (str, optional): 系统提示，默认为 "You are a helpful assistant."
    
    Returns:
        str: 模型的响应文本
    """
    # 设置默认系统提示
    if system_prompt is None:
        system_prompt = "You are a helpful assistant."
    
    # 构建消息列表
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": prompt}
    ]
    
    print(f"正在调用模型: {model_name}")
    print(f"输入提示长度: {len(prompt)} 字符")
    
    # 调用文本生成API
    response = Generation.call(
        api_key=os.getenv('DASHSCOPE_API_KEY'),
        model=model_name,
        messages=messages
    )
    
    # 获取模型响应文本
    response_text = response.output.text
    return response_text


def call_qwen_text_models_with_history(model_name, messages, system_prompt=None):
    """
    调用通义千问文本模型处理文本（支持多轮对话历史）
    
    Args:
        model_name (str): 模型名称，如 "qwen-max", "qwen-plus", "qwen-turbo"
        messages (list): 消息历史列表，格式为 [{"role": "user", "content": "..."}, {"role": "assistant", "content": "..."}, ...]
        system_prompt (str, optional): 系统提示，默认为 "You are a helpful assistant."
    
    Returns:
        str: 模型的响应文本
    """
    # 设置默认系统提示
    if system_prompt is None:
        system_prompt = "You are a helpful assistant."
    
    # 构建完整的消息列表（在开头添加系统提示）
    full_messages = [{"role": "system", "content": system_prompt}] + messages
    
    print(f"正在调用模型: {model_name}")
    print(f"对话轮数: {len([m for m in messages if m['role'] == 'user'])}")
    
    # 调用文本生成API
    response = Generation.call(
        api_key=os.getenv('DASHSCOPE_API_KEY'),
        model=model_name,
        messages=full_messages
    )
    
    # 获取模型响应文本
    response_text = response.output.text
    return response_text


if __name__ == "__main__":
    response_text = call_qwen_text_models("qwen-max", "你好，我是小明，很高兴认识你。")
    print(response_text)