from markdown2text import read_markdown
from base_prompt import prompt
from call_qwen_text_models import call_qwen_text_models

content = read_markdown("E:\gitProjects\mineru\prompt_improved\markdown\帝威 2025.8.1-8.31费用确认.md")

final_prompt = prompt + content + """ 立即输出纯 JSON 格式结果："""

response_text = call_qwen_text_models("qwen-max", final_prompt)
print(response_text)